package com.example.practica01diegoivansotoarreola

data class Producto (
    val nombreProducto: String,
    val precio: Double,

)