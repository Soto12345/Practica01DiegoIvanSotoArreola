package com.example.practica01diegoivansotoarreola

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast

class MainActivity : AppCompatActivity() {
    private lateinit var correo: EditText
    private lateinit var contrasena: EditText

    private val usuarios = listOf(
        Usuario("diego@gmail.com", "12345"),
        Usuario("ivan@gmail.com", "12345"),
        Usuario("soto@gmail.com", "12345"),
        Usuario("arreola@gmail.com", "12345"),
    )
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        correo = findViewById(R.id.edtCorreo)
        contrasena = findViewById(R.id.edtContrasena)

        val btnIngresar: View = findViewById(R.id.btnIngresar)
        btnIngresar.setOnClickListener { aceptar() }

        val btnSalir: Button = findViewById(R.id.btnSalir)
        btnSalir.setOnClickListener { salir() }
    }
    private fun aceptar() {
        val inputCorreo = correo.text.toString()
        val inputContrasena = contrasena.text.toString()

        if (inputCorreo.isBlank() || inputContrasena.isBlank()) {

            Toast.makeText(this, "Falta completar los campos", Toast.LENGTH_SHORT).show()
            return
        }

        val usuario = usuarios.find { it.correo == inputCorreo && it.contrasena == inputContrasena }
        if (usuario != null) {
            val intent = Intent(this,activity_menu::class.java)
            startActivity(intent)
        } else {
            Toast.makeText(this, "Datos Erróneos", Toast.LENGTH_SHORT).show()
        }
    }

    private fun salir() {
        finishAffinity()
    }
}