package com.example.practica01diegoivansotoarreola

data class Usuario(
    val correo: String,
    val contrasena: String
)