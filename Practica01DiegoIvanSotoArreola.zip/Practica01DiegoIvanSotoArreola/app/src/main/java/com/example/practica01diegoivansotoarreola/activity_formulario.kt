package com.example.practica01diegoivansotoarreola

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.core.app.NotificationManagerCompat

class activity_formulario : AppCompatActivity() {
    private lateinit var edtNombreProducto: EditText
    private lateinit var edtPrecio: EditText
    private lateinit var btnAgregarProducto: Button

    private val productos = mutableListOf<Producto>()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_formulario)
        NotificationManagerCompat.from(this).apply {
            cancel(activity_menu.notificationId)
        }

        setSupportActionBar(findViewById(R.id.barraFormulario))
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        edtNombreProducto = findViewById(R.id.edtNombreProducto)
        edtPrecio = findViewById(R.id.edtPrecio)
        btnAgregarProducto = findViewById(R.id.btnAgregarProducto)
        btnAgregarProducto.setOnClickListener { onAgregarProductoClick() }
    }


    private fun onAgregarProductoClick() {
        val nombreProducto = edtNombreProducto.text.toString()
        val precioString = edtPrecio.text.toString()

        if (nombreProducto.isEmpty() || precioString.isEmpty()) {
            Toast.makeText(this, "Por favor, completa todos los campos.", Toast.LENGTH_SHORT).show()
        } else {
            val precio = precioString.toDoubleOrNull()
            if (precio == null) {
                Toast.makeText(this, "Por favor, ingresa un precio válido.", Toast.LENGTH_SHORT).show()
            } else {
                val producto = Producto(
                    nombreProducto = nombreProducto,
                    precio = precio,

                )

                productos.add(producto)

                Toast.makeText(this, "Producto agregado con éxito.", Toast.LENGTH_SHORT).show()

                edtNombreProducto.text.clear()
                edtPrecio.text.clear()

                val intent = Intent(this, activity_consultar::class.java).apply {
                    putExtra("nombre del producto", nombreProducto)
                    putExtra("precio", precioString)
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                }
                startActivity(intent)
            }
        }
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            val intent = Intent(this, activity_menu::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            }
            startActivity(intent)
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}