package com.example.practica01diegoivansotoarreola

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.widget.TextView
import androidx.core.app.NotificationManagerCompat

class activity_consultar : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_consultar)
        NotificationManagerCompat.from(this).apply {
            cancel(activity_menu.notificationId)
        }

        setSupportActionBar(findViewById(R.id.barraConsultar))
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val nombreProducto = intent.getStringExtra("nombre del producto")
        val precio = intent.getStringExtra("precio")


        val textView = findViewById<TextView>(R.id.textView)
        textView.text = "Nombre del Producto: $nombreProducto\nPrecio: $precio"
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        if (item.itemId == android.R.id.home) {
            val intent = Intent(this, activity_menu::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            }
            startActivity(intent)
            return true
        }
        return super.onOptionsItemSelected(item)
    }
}